@echo off
start javaw -jar proliferation.jar